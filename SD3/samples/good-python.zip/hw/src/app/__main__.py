from app.core import greet

if __name__ == "__main__":
    print(greet("ВышBuild"))
