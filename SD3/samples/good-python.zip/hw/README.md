# ДЗ-3

Запуск: `python -m app`
