def main(:
    print('почти собралось')

if __name__ == '__main__':
    main()
